import logging
import dotenv

dotenv.load_dotenv()
logging.basicConfig(level=logging.INFO)
